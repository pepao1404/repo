<?php
header("Location: void.php");